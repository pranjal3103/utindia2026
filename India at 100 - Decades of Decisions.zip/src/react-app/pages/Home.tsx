import { useEffect } from 'react';
import { Calendar, MapPin, Clock } from 'lucide-react';
export default function HomePage() {
  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Inter:wght@400;500;600&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
  }, []);
  return <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md border-b border-slate-200 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="https://019b86b4-7be2-7b54-9f40-75529ba72f1a.mochausercontent.com/af2d70188e718e4363e3a183a70bc155.png" alt="Conference Logo" className="h-12 w-auto" />
            <div>
              <div className="font-semibold" style={{
              fontFamily: 'Inter, sans-serif'
            }}>
                <span className="text-slate-900">India at </span>
                <span className="bg-gradient-to-b from-[#FF9933] from-0% via-[#FFFFFF] via-33% to-[#138808] from-66% bg-clip-text text-transparent" style={{
                WebkitTextStroke: '0.5px rgba(0,0,0,0.1)'
              }}>100</span>
              </div>
              <div className="text-xs text-slate-600">UT Austin Conference</div>
            </div>
          </div>
          <div className="hidden md:flex gap-8">
            <a href="#about" className="text-slate-700 hover:text-orange-600 transition-colors font-medium">About</a>
            <a href="#schedule" className="text-slate-700 hover:text-orange-600 transition-colors font-medium">Schedule</a>
            <a href="#speakers" className="text-slate-700 hover:text-orange-600 transition-colors font-medium">Speakers</a>
            <a href="#venue" className="text-slate-700 hover:text-orange-600 transition-colors font-medium">Venue</a>
          </div>
          <a href="https://forms.gle/4X9J3D8SnLUkgygt9" target="_blank" rel="noopener noreferrer" className="px-6 py-2 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-lg font-semibold hover:shadow-lg hover:scale-105 transition-all inline-block">
            Register
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{
        backgroundImage: `url('https://019b86b4-7be2-7b54-9f40-75529ba72f1a.mochausercontent.com/hero-background.png')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }} />
        <div className="absolute inset-0 bg-gradient-to-b from-orange-50/50 via-white/80 to-white" />
        
        <div className="max-w-6xl mx-auto text-center relative z-10">
          <div className="inline-block px-4 py-2 bg-orange-100 text-orange-700 rounded-full text-sm font-semibold mb-6">
            Academic Conference 2026
          </div>
          
          <h1 className="text-6xl md:text-7xl font-black mb-6 leading-tight" style={{
          fontFamily: 'Playfair Display, serif'
        }}>
            <span className="text-slate-800">India at </span>
            <span className="bg-gradient-to-b from-[#FF9933] from-0% via-[#FFFFFF] via-33% to-[#138808] from-66% bg-clip-text text-transparent" style={{
            WebkitTextStroke: '1px rgba(0,0,0,0.1)'
          }}>100</span>
          </h1>
          
          <h2 className="text-3xl md:text-4xl font-bold text-slate-700 mb-8" style={{
          fontFamily: 'Playfair Display, serif'
        }}>
            Decades of Decisions
          </h2>
          
          <p className="text-xl text-slate-600 max-w-3xl mx-auto mb-12 leading-relaxed">
            Join us for a comprehensive exploration of India's transformative journey, 
            examining the pivotal decisions that have shaped the nation's past, present, and future.
          </p>

          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <div className="flex items-center gap-2 px-6 py-3 bg-white rounded-xl shadow-md border border-slate-200">
              <Calendar className="w-5 h-5 text-orange-600" />
              <span className="font-semibold text-slate-800">April 10, 2026</span>
            </div>
            <div className="flex items-center gap-2 px-6 py-3 bg-white rounded-xl shadow-md border border-slate-200">
              <MapPin className="w-5 h-5 text-orange-600" />
              <span className="font-semibold text-slate-800">McCombs School of Business</span>
            </div>
            <div className="flex items-center gap-2 px-6 py-3 bg-white rounded-xl shadow-md border border-slate-200">
              <Clock className="w-5 h-5 text-orange-600" />
              <span className="font-semibold text-slate-800">1:00 PM - 7:30 PM</span>
            </div>
          </div>

          <a href="https://forms.gle/4X9J3D8SnLUkgygt9" target="_blank" rel="noopener noreferrer" className="px-10 py-4 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-xl font-bold text-lg hover:shadow-2xl hover:scale-105 transition-all inline-block">
            Register Now
          </a>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-6 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-8 text-center" style={{
          fontFamily: 'Playfair Display, serif'
        }}>
            About the Conference
          </h2>
          
          <div className="max-w-5xl mx-auto">
            <p className="text-lg text-slate-300 mb-6 leading-relaxed">
              Join us for the inaugural UT Austin India Conference, a landmark event hosted by the McCombs School of Business with support from the Lyndon B. Johnson School of Public Affairs and the South Asia Institute.
            </p>
            
            <p className="text-lg text-slate-300 mb-6 leading-relaxed">
              Centered around the theme "Decades of Decisions," this conference brings together thought leaders, faculty, students, and dignitaries to explore the pivotal choices shaping India's future. As the economist Joan Robinson once famously noted, "Whatever you can rightly say about India, the opposite is also true"—a sentiment that underscores the complexity and dynamism we will explore throughout the day.
            </p>

            <div className="bg-gradient-to-br from-orange-600/20 to-green-600/20 p-8 rounded-2xl backdrop-blur-sm border border-white/10 mt-12 mb-12">
              <h3 className="text-2xl font-bold mb-6" style={{
              fontFamily: 'Playfair Display, serif'
            }}>
                What to Expect
              </h3>
              
              <p className="text-slate-200 mb-6 leading-relaxed">
                The conference will dive deep into the forces driving India's growth trajectory and its evolving role on the global stage. Through a series of curated panels and keynote conversations, we will cover critical intersections of:
              </p>

              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2" />
                  <div>
                    <span className="text-slate-100 font-semibold">Business & Economy:</span>
                    <span className="text-slate-200"> Sustainable growth models and India's development acceleration.</span>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2" />
                  <div>
                    <span className="text-slate-100 font-semibold">Policy & Relations:</span>
                    <span className="text-slate-200"> The future of Indo-US and Texas-India ties.</span>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2" />
                  <div>
                    <span className="text-slate-100 font-semibold">Technology:</span>
                    <span className="text-slate-200"> The "Brave New World" of India and Artificial Intelligence.</span>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2" />
                  <div>
                    <span className="text-slate-100 font-semibold">Culture & Society:</span>
                    <span className="text-slate-200"> Insights into media storytelling, cinema, and the pursuit of happiness.</span>
                  </div>
                </li>
              </ul>
            </div>

            <div className="bg-white/5 p-8 rounded-2xl border border-white/10">
              <h3 className="text-2xl font-bold mb-4 text-orange-400" style={{
              fontFamily: 'Playfair Display, serif'
            }}>
                Who Should Attend
              </h3>
              <p className="text-lg text-slate-300 leading-relaxed">
                This event is designed for students, alumni, faculty, and professionals interested in the economic, political, and cultural currents connecting India and the world.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Schedule Section */}
      <section id="schedule" className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center text-slate-900" style={{
          fontFamily: 'Playfair Display, serif'
        }}>
            Conference Schedule
          </h2>
          
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-orange-50 to-green-50 rounded-2xl p-8 shadow-lg border border-orange-200">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-orange-600 text-white px-4 py-2 rounded-lg font-bold">
                  1:00 PM
                </div>
                <h3 className="text-2xl font-bold text-slate-900" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  Keynote - Decades of Decisions
                </h3>
              </div>
              <p className="text-slate-700 ml-28 font-medium">
                Speaker in conversation with...
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200 hover:shadow-xl transition-shadow">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-orange-100 text-orange-700 px-4 py-2 rounded-lg font-bold">
                  1:30 PM
                </div>
                <h3 className="text-2xl font-bold text-slate-900" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  1/6th of Humanity
                </h3>
              </div>
              <p className="text-slate-600 ml-28">
                Dr. Arvind Subramanian, Dr. Devesh Kapur in conversation with Prof. Dilawar Syed
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200 hover:shadow-xl transition-shadow">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-orange-100 text-orange-700 px-4 py-2 rounded-lg font-bold">
                  2:15 PM
                </div>
                <h3 className="text-2xl font-bold text-slate-900" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  Growth - The Sustainable Way
                </h3>
              </div>
              <p className="text-slate-600 ml-28">
                Speaker 1 and Speaker 2 in conversation with Dr. Meetha Kothare
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200 hover:shadow-xl transition-shadow">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-orange-100 text-orange-700 px-4 py-2 rounded-lg font-bold">
                  3:00 PM
                </div>
                <h3 className="text-2xl font-bold text-slate-900" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  Future of Indo-US-TX Relations
                </h3>
              </div>
              <p className="text-slate-600 ml-28">
                Sh. Manjunath, Vivek Mohindra, Aaron Demerson in conversation with Moderator
              </p>
            </div>

            <div className="bg-gradient-to-r from-slate-100 to-slate-50 rounded-2xl p-8 shadow-lg border border-slate-300">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-slate-600 text-white px-4 py-2 rounded-lg font-bold">
                  3:45 PM
                </div>
                <h3 className="text-2xl font-bold text-slate-900" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  Networking Break: Think and Drink and Network
                </h3>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200 hover:shadow-xl transition-shadow">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-orange-100 text-orange-700 px-4 py-2 rounded-lg font-bold">
                  4:15 PM
                </div>
                <h3 className="text-2xl font-bold text-slate-900" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  Brave New World - India and AI
                </h3>
              </div>
              <p className="text-slate-600 ml-28">
                Gaurav Tembey, Speaker 2, Speaker 3 in conversation with Sandeep Chennakeshu
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200 hover:shadow-xl transition-shadow">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-orange-100 text-orange-700 px-4 py-2 rounded-lg font-bold">
                  5:00 PM
                </div>
                <h3 className="text-2xl font-bold text-slate-900" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  Accelerating India's Development
                </h3>
              </div>
              <p className="text-slate-600 ml-28">
                Karthik Murlidharan in conversation with Dr. Kishore Gawande
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200 hover:shadow-xl transition-shadow">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-orange-100 text-orange-700 px-4 py-2 rounded-lg font-bold">
                  5:45 PM
                </div>
                <h3 className="text-2xl font-bold text-slate-900" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  The Happiness Hypothesis
                </h3>
              </div>
              <p className="text-slate-600 ml-28">
                Dr. Raj Raghunathan
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200 hover:shadow-xl transition-shadow">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-orange-100 text-orange-700 px-4 py-2 rounded-lg font-bold">
                  6:15 PM
                </div>
                <h3 className="text-2xl font-bold text-slate-900" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  Media Storytelling and Identity
                </h3>
              </div>
              <p className="text-slate-600 ml-28">
                Saurabh Dwivedi in conversation with Moderator
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg border border-slate-200 hover:shadow-xl transition-shadow">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-orange-100 text-orange-700 px-4 py-2 rounded-lg font-bold">
                  6:45 PM
                </div>
                <h3 className="text-2xl font-bold text-slate-900" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  The Cinema Imperatives
                </h3>
              </div>
              <p className="text-slate-600 ml-28">
                Speaker 1 in conversation with Alka Bhanot
              </p>
            </div>

            <div className="bg-gradient-to-r from-orange-50 to-green-50 rounded-2xl p-8 shadow-lg border border-orange-200">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-orange-600 text-white px-4 py-2 rounded-lg font-bold">
                  7:15 PM
                </div>
                <h3 className="text-2xl font-bold text-slate-900" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  Closing Comments
                </h3>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Speakers Section */}
      <section id="speakers" className="py-20 px-6 bg-gradient-to-br from-slate-50 to-orange-50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-center text-slate-900" style={{
          fontFamily: 'Playfair Display, serif'
        }}>
            Featured Speakers
          </h2>
          <p className="text-center text-slate-600 mb-12 text-lg">
            Leading experts and scholars from around the world
          </p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 rounded-xl mb-4 overflow-hidden bg-slate-100 flex items-center justify-center">
                <img src="https://019b86b4-7be2-7b54-9f40-75529ba72f1a.mochausercontent.com/Aaron.png" alt="Aaron Demerson" className="w-full h-full object-contain" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Aaron Demerson</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">CEO, Texas Economic Development Corporation</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                Leading Texas' business attraction and expansion efforts, he brings a critical perspective on the deepening economic and commercial ties between Texas and India.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 rounded-xl mb-4 overflow-hidden bg-slate-100 flex items-center justify-center">
                <img src="https://019b86b4-7be2-7b54-9f40-75529ba72f1a.mochausercontent.com/Alka.png" alt="Alka Bhanot" className="w-full h-full object-contain" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Alka Bhanot</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">Co-Founder, Indie Meme</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                A filmmaker and festival director, she champions South Asian independent cinema and will lead the conversation on storytelling and cultural identity.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 rounded-xl mb-4 overflow-hidden bg-slate-100 flex items-center justify-center">
                <img src="https://019b86b4-7be2-7b54-9f40-75529ba72f1a.mochausercontent.com/Arvind.png" alt="Arvind Subramanian" className="w-full h-full object-contain" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Arvind Subramanian</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">Senior Fellow, Brown University & Former Chief Economic Advisor to the Government of India</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                A world-renowned economist, he offers authoritative insights into India's macroeconomic landscape and the "Decades of Decisions" that have shaped its current trajectory.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 rounded-xl mb-4 overflow-hidden bg-slate-100 flex items-center justify-center">
                <img src="https://019b86b4-7be2-7b54-9f40-75529ba72f1a.mochausercontent.com/D.C-Manjunath.jpeg" alt="D.C. Manjunath" className="w-full h-full object-contain" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">D.C. Manjunath</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">Consul General of India, Houston</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                As the lead diplomat for India in the region, he facilitates the vital government-to-government and trade relationships connecting India with Texas and the southern US.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 rounded-xl mb-4 overflow-hidden bg-slate-100 flex items-center justify-center">
                <img src="https://019b86b4-7be2-7b54-9f40-75529ba72f1a.mochausercontent.com/Devesh.png" alt="Devesh Kapur" className="w-full h-full object-contain" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Devesh Kapur</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">Professor of South Asian Studies, Johns Hopkins University</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                A leading scholar on Indian public institutions and the diaspora, he brings deep expertise on migration, human capital, and the social transformation of India.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 rounded-xl mb-4 overflow-hidden bg-slate-100 flex items-center justify-center">
                <img src="https://019b86b4-7be2-7b54-9f40-75529ba72f1a.mochausercontent.com/Dilawar.jpg" alt="Dilawar Syed" className="w-full h-full object-contain" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Dilawar Syed</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">Professor of Practice, UT Austin & Former Deputy Administrator, US SBA</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                With a background in both Silicon Valley entrepreneurship and high-level US federal service, he bridges the worlds of technology, policy, and commercial diplomacy.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 rounded-xl mb-4 overflow-hidden bg-slate-100 flex items-center justify-center">
                <img src="https://019b86b4-7be2-7b54-9f40-75529ba72f1a.mochausercontent.com/Gaurav.png" alt="Gaurav Tembey" className="w-full h-full object-contain" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Gaurav Tembey</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">Managing Director & Partner, Boston Consulting Group</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                An expert in the Technology, Media, and Telecom (TMT) practice, he specializes in semiconductors and digital transformation, key pillars of the US-India tech partnership.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 bg-gradient-to-br from-violet-100 to-purple-100 rounded-xl mb-4" />
              <h3 className="text-xl font-bold text-slate-900 mb-2">Karthik Murlidharan</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">Professor of Economics, UC San Diego & Founder, CEGIS</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                A premier development economist, he focuses on improving state capacity and public service delivery in India, offering data-driven solutions for accelerating development.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 bg-gradient-to-br from-slate-100 to-gray-100 rounded-xl mb-4" />
              <h3 className="text-xl font-bold text-slate-900 mb-2">Kishore Gawande</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">Professor of Business & Public Policy, UT Austin</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                His research lies at the intersection of political economy and international trade, providing the academic framework for understanding India's developmental challenges.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 bg-gradient-to-br from-rose-100 to-pink-100 rounded-xl mb-4" />
              <h3 className="text-xl font-bold text-slate-900 mb-2">Meetha Kothare</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">Professor of Practice, UT Austin</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                A specialist in social innovation and sustainability, she guides the dialogue on how India can balance rapid economic growth with environmental and social responsibility.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 bg-gradient-to-br from-lime-100 to-green-100 rounded-xl mb-4" />
              <h3 className="text-xl font-bold text-slate-900 mb-2">Raj Raghunathan</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">Professor of Marketing, UT Austin</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                Known as "Dr. Happiness," his work explores the psychology of well-being, bringing a unique behavioral science perspective to the quality of life in a growing economy.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 rounded-xl mb-4 overflow-hidden bg-slate-100 flex items-center justify-center">
                <img src="https://019b86b4-7be2-7b54-9f40-75529ba72f1a.mochausercontent.com/Sandeep.jpg" alt="Sandeep Chennakeshu" className="w-full h-full object-contain" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Sandeep Chennakeshu</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">Author & Former Technology Executive</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                A veteran of the mobile and semiconductor industries and author of Your Company is Your Castle, he provides seasoned leadership insights for the "Brave New World" of AI and tech.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 bg-gradient-to-br from-fuchsia-100 to-purple-100 rounded-xl mb-4" />
              <h3 className="text-xl font-bold text-slate-900 mb-2">Saurabh Dwivedi</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">Founder & Editor, The Lallantop</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                A pioneering digital journalist, he created one of India's most popular new media platforms, offering a pulse on the changing narratives and identity of the Indian heartland.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="w-full h-48 bg-gradient-to-br from-orange-100 to-amber-100 rounded-xl mb-4" />
              <h3 className="text-xl font-bold text-slate-900 mb-2">Vivek Mohindra</h3>
              <p className="text-orange-600 font-semibold mb-3 text-sm">SVP Corporate Strategy, Dell Technologies</p>
              <p className="text-slate-600 text-sm leading-relaxed">
                With deep experience in global corporate strategy, he represents the major multinational tech investment that anchors the India-Texas business corridor.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Venue Section */}
      <section id="venue" className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center text-slate-900" style={{
          fontFamily: 'Playfair Display, serif'
        }}>
            Venue
          </h2>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold mb-4 text-slate-900" style={{
              fontFamily: 'Playfair Display, serif'
            }}>
                McCombs School of Business
              </h3>
              <p className="text-lg text-slate-700 mb-6">
                The University of Texas at Austin
              </p>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-start gap-3">
                  <MapPin className="w-6 h-6 text-orange-600 mt-1" />
                  <div>
                    <div className="font-semibold text-slate-900">Address</div>
                    <div className="text-slate-600">2110 Speedway, Austin, TX 78712</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="w-6 h-6 text-orange-600 mt-1" />
                  <div>
                    <div className="font-semibold text-slate-900">Date & Time</div>
                    <div className="text-slate-600">April 10, 2026 • 1:00 PM - 7:30 PM</div>
                  </div>
                </div>
              </div>

              <button className="px-8 py-3 bg-slate-900 text-white rounded-xl font-semibold hover:bg-slate-800 transition-colors">
                Get Directions
              </button>
            </div>
            
            <div className="rounded-2xl h-96 overflow-hidden shadow-lg">
              <img src="https://019b86b4-7be2-7b54-9f40-75529ba72f1a.mochausercontent.com/image.png_3020.png" alt="McCombs School of Business" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Registration CTA */}
      <section className="py-20 px-6 bg-gradient-to-r from-orange-600 to-orange-500">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white" style={{
          fontFamily: 'Playfair Display, serif'
        }}>
            Join Us for This Historic Discussion
          </h2>
          <p className="text-xl text-orange-100 mb-8">
            Secure your spot at India at 100: Decades of Decisions
          </p>
          <a href="https://forms.gle/4X9J3D8SnLUkgygt9" target="_blank" rel="noopener noreferrer" className="px-10 py-4 bg-white text-orange-600 rounded-xl font-bold text-lg hover:shadow-2xl hover:scale-105 transition-all inline-block">
            Register Now
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center gap-3 mb-6">
            <img src="https://019b86b4-7be2-7b54-9f40-75529ba72f1a.mochausercontent.com/af2d70188e718e4363e3a183a70bc155.png" alt="Conference Logo" className="h-16 w-auto" />
            <div className="text-left">
              <div className="font-bold text-lg" style={{
              fontFamily: 'Playfair Display, serif'
            }}>
                <span className="text-white">India at </span>
                <span className="bg-gradient-to-b from-[#FF9933] from-0% via-[#FFFFFF] via-33% to-[#138808] from-66% bg-clip-text text-transparent" style={{
                WebkitTextStroke: '0.5px rgba(255,255,255,0.2)'
              }}>100</span>
              </div>
              <div className="text-sm text-slate-400">Decades of Decisions</div>
            </div>
          </div>
          
          <p className="text-slate-400 mb-4">
            McCombs School of Business, University of Texas at Austin
          </p>
          <p className="text-slate-400 text-sm">
            April 10, 2026 • Austin, Texas
          </p>
          
          <div className="mt-8 pt-8 border-t border-slate-800 text-slate-500 text-sm">
            © 2026 University of Texas at Austin. All rights reserved.
          </div>
        </div>
      </footer>
    </div>;
}